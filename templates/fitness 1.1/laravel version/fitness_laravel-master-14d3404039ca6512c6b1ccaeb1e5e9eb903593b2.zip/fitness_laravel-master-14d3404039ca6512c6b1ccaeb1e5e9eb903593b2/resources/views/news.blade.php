@extends('layouts/default')

{{-- Page title --}}
@section('title')
    News
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/datatables/css/dataTables.bootstrap.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/vendors/sweetalert2/css/sweetalert2.min.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/css/pages/news.css') }}" rel="stylesheet"/>
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>News</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="#">News</a>
            </li>
            <li class="active">
                News
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Basic charts strats here-->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-newspaper-o" aria-hidden="true"></i> News
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body table-responsive">
                            <table class="table table-bordered text-center" id="fitness-table">
                                <thead>
                                <tr>
                                    <th class="text-center">Date</th>
                                    <th class="text-center">Category</th>
                                    <th class="text-center">Title</th>
                                    <th class="text-center">Edit/Save</th>
                                    <th class="text-center">Delete/Cancel</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>24-09-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>06-09-2016</td>
                                    <td>Fitness</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>17-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-10-2016</td>
                                    <td>Flexibility</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>02-10-2016</td>
                                    <td>Fitness</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>24-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>26-09-2016</td>
                                    <td>Fitness</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>15-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>12-10-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>12-10-2016</td>
                                    <td>Flexibility</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>24-09-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>06-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>17-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-10-2016</td>
                                    <td>Flexibility</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>02-10-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>24-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>26-09-2016</td>
                                    <td>Fitness</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>15-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>12-10-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>12-10-2016</td>
                                    <td>Flexibility</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>24-09-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>06-09-2016</td>
                                    <td>Fitness</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>17-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-10-2016</td>
                                    <td>Flexibility</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>02-10-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>24-09-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>21-09-2016</td>
                                    <td>Aerobics</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>26-09-2016</td>
                                    <td>Fitness</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>15-09-2016</td>
                                    <td>Body Building</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>12-10-2016</td>
                                    <td>Yoga</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>12-10-2016</td>
                                    <td>Flexibility</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row ends -->
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- global js -->
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/sweetalert2/js/sweetalert2.min.js') }}"></script>
    <!-- end of page level js -->
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/pages/news.js') }}"></script>
@stop
