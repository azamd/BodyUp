@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Events List
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/css/pages/events.css') }}" rel="stylesheet">
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Events List</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="#">Events</a>
            </li>
            <li class="active">
                Events List
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <!--main content-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-fw fa-list"></i> Events List
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body">
                            <div class="mart">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/1.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="user_eventitem">One Week Yoga Special Training by -
                                                        John C</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 16 / 09 / 2016 - 21 / 09 / 2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/2.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="#">Personal Training happy week</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 03 / 09 / 2016 - 09 / 09 / 2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mart">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/3.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="#">5k Marthon</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 25 / 08 / 2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/4.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="#">Soul Searching</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 18 / 08 / 2016 - 20 / 08 / 2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mart">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/5.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="#">XT Series Championship</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 15 / 07 / 2016 - 17 / 07 / 2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/6.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="#">5k Marthon - Joe S. Esparza</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 05 / 07 / 2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mart">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <div class="col-sm-4 col-lg-2">
                                                <img src="{{asset('assets/img/events/7.png')}}"
                                                     class="img-responsive img-thumbnail img-circle"
                                                     alt="image not found">
                                            </div>
                                            <div class="col-sm-8 col-lg-10">
                                                <h4>
                                                    <a href="#">Free Nutrition Seminor</a>
                                                </h4>
                                                <p class="paragraph_text_color">Lorem Ipsum is simply dummy text of the
                                                    printing and typesetting industry.</p>
                                                <p class="paragraph_text_color"> Lorem Ipsum has been the industry's
                                                    standard dummy text ever since the 1500s, when an unknown printer
                                                    took a galley of type and scrambled it to make a type specimen
                                                    book.</p>
                                                <ul class="sub-menu">
                                                    <li class="paragraph_text_color">
                                                        <i class="fa fa-calendar"></i> 25 / 06 /2016
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--row ends-->
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <!-- end of page level js -->
@stop
