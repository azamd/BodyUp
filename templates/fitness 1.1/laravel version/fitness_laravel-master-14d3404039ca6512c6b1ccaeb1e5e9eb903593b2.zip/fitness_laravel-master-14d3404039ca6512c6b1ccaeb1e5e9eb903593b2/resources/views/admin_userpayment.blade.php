@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Payments
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/datatables/css/dataTables.bootstrap.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/css/pages/payment.css') }}" rel="stylesheet">
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Payments</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="#">Users</a>
            </li>
            <li class="active">
                Payments
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-9">
                    <div class="box-model">
                        <h5>Pending Payments</h5>
                        <div id="bar-chart-stacked" class="flotChart1"></div>
                    </div>
                </div>
                <div class="col-lg-3 ">
                    <div class="box-model">
                        <h5 class="text-primary">Pending Payments</h5>
                        <h5 class="text-danger">$500.63</h5>
                        <table class="table">
                            <tbody>
                            <tr>
                                <th>User name</th>
                                <th>Total</th>
                            </tr>
                            <tr>
                                <td>Gavin</td>
                                <td>$61.45</td>
                            </tr>
                            <tr>
                                <td>Bella</td>
                                <td>$50</td>
                            </tr>
                            <tr>
                                <td>Jacob</td>
                                <td>$10</td>
                            </tr>
                            <tr>
                                <td>Markotto</td>
                                <td>$80</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Basic charts strats here-->
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-fw fa-file-text-o"></i> Pending Payments
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body table-responsive">
                            <table class="table table-bordered" id="fitness-table">
                                <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Course</th>
                                    <th>Trainer Name</th>
                                    <th>Email</th>
                                    <th>Payment Due</th>
                                    <th>Total Amount</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Bella</td>
                                    <td>Yoga</td>
                                    <td>John Doe</td>
                                    <td>gankunding@hotmail.com</td>
                                    <td>$20</td>
                                    <td>$60</td>
                                </tr>
                                <tr>
                                    <td>JacobThornton</td>
                                    <td>Fitness</td>
                                    <td>Clara S.Roberson</td>
                                    <td>JacobThornton@test.com</td>
                                    <td>$10</td>
                                    <td>$80</td>
                                </tr>
                                <tr>
                                    <td>Markotto</td>
                                    <td>Aerobics</td>
                                    <td>Dominick Williams</td>
                                    <td>Markotto@test.com</td>
                                    <td>$50</td>
                                    <td>$120</td>
                                </tr>
                                <tr>
                                    <td>Sonya</td>
                                    <td>Body Building</td>
                                    <td>Darin Gross</td>
                                    <td>Sonya@test.com</td>
                                    <td>$20</td>
                                    <td>$100</td>
                                </tr>
                                <tr>
                                    <td>Gavin</td>
                                    <td>Yoga</td>
                                    <td>John Doe</td>
                                    <td>Gavin@test.com</td>
                                    <td>$30</td>
                                    <td>$40</td>
                                </tr>
                                <tr>
                                    <td>Timothy</td>
                                    <td>Life Time Membership</td>
                                    <td>Clara S.Roberson</td>
                                    <td>Timothy@test.com</td>
                                    <td>$50</td>
                                    <td>$100</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row ends -->
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/flotchart/js/jquery.flot.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/flotchart/js/jquery.flot.resize.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/flotchart/js/jquery.flot.categories.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/flotchart/js/jquery.flot.tooltip.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/payment.js') }}"></script>
    <!-- end of page level js -->
@stop
