<!DOCTYPE html>
<html>

<head>
    <title>404 | Fit2Go Admin Template</title>
<link rel="shortcut icon" href="favicon.ico" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- global level css -->
    <link type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet" />
    <!-- end of global css-->
    <!-- page level styles-->
    <link href="{{asset('assets/css/pages/404.css')}}" rel="stylesheet" type="text/css">
</head>

<body>
    <div class="container">
        <div class="col-md-8 content text-center">
            <a href="index.blade.php"><img src="{{asset('assets/img/404.png')}}" class="img-responsive animated bounceInLeft rotate" alt="image not found"></a>
        </div>
        <div class="col-md-4 text-center page_alignment">
            <h1>404 ERROR</h1>
            <a href="index" class="btn btn-primary btn-lg button-alignments">Home</a>
        </div>
    </div>
    <!-- global js -->
    <script src="{{asset('assets/js/jquery.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('assets/js/bootstrap.min.js')}}" type="text/javascript"></script>
    <!-- end of global js -->
</body>

</html>
