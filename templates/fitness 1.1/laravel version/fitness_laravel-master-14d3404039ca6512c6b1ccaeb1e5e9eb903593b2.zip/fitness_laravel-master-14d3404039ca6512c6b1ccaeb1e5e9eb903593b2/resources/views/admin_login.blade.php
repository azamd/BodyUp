<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login | Fit2Go Admin Template</title>
    <link rel="shortcut icon" href="{{ asset('assets/img/favicon.ico') }}"/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- global level css -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/app.css') }}">
    <!-- end of global css-->
    <!-- page level styles-->
    <link type="text/css" href="{{ asset('assets/vendors/bootstrapvalidator/css/bootstrapValidator.min.css') }}" rel="stylesheet"/>
    <link href="{{asset('assets/vendors/iCheck/css/all.css')}}" rel="stylesheet" type="text/css">
    <link href="{{ asset('assets/css/pages/admin-login.css') }}" rel="stylesheet" type="text/css">
    <!-- end of page level styles-->
</head>

<body>
<div class="container">
    <div class="full-content-center">
        <div class="box bounceInLeft animated">
            <img src="{{asset('assets/img/logo.png')}}" class="logo" alt="image not found">
            <h3 class="text-center">Admin Log In</h3>
            <form class="form" id="log_in" method="post">
                <div class="form-group">
                    <label class="sr-only"></label>
                    <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label class="sr-only"></label>
                    <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>
                <div class="checkbox text-left">
                    <label>
                        <input type="checkbox"> Remember Password
                    </label>
                </div>
                <a href="index" class="btn btn-block btn-warning">Log In</a>
            </form>
            <p class="text-right"><a href="user_forgot" class="text-primary forgot_color">Forgot Password?</a></p>
        </div>
    </div>
</div>
<!-- global js -->
<script type="text/javascript" src="{{ asset('assets/js/app.js') }}"></script>
<!-- end of global js -->
<!-- begining of page level js -->
<script src="{{asset('assets/vendors/iCheck/js/icheck.js')}}" type="text/javascript"></script>
<script type="text/javascript" src="{{ asset('assets/vendors/bootstrapvalidator/js/bootstrapValidator.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/pages/login1.js') }}"></script>
<!-- end of page level js -->
</body>

</html>
