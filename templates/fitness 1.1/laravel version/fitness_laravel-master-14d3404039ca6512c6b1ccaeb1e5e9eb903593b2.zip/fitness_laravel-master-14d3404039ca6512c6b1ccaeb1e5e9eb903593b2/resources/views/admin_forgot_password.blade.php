<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login | Fit2Go Admin Template</title>
    <link rel="shortcut icon" href="{{asset('assets/img/favicon.ico')}}" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- global level css -->
    <!-- global level css -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/app.css') }}">
    <!-- end of global css-->
    <!-- page level styles-->
    <link type="text/css" href="{{ asset('assets/vendors/bootstrapvalidator/css/bootstrapValidator.min.css') }}" rel="stylesheet" />
    <link href="{{asset('assets/vendors/iCheck/css/all.css')}}" rel="stylesheet" type="text/css">
    <link  rel="stylesheet" href="{{ asset('assets/css/pages/admin-login.css') }}">
    <!-- end of page level styles-->
</head>

<body>
    <div class="container">
        <div class="full-content-center">
            <div class="box bounceInLeft animated">
                <img src="{{asset('assets/img/logo.png')}}" class="logo" alt="image not found">
                <h3 class="text-center">Forgot Password</h3>
                <form class="form" id="forgot_password" method="post">
                    <div class="form-group">
                        <label class="sr-only"></label>
                        <input type="email" class="form-control" name="email_for" placeholder="Email" required>
                    </div>
                    <input type="submit" class="btn btn-block btn-warning" value="Submit">
                </form>
            </div>
        </div>
    </div>
    <!-- global js -->
    <script type="text/javascript" src="{{ asset('assets/js/app.js') }}"></script>
    <!-- end of global js -->
    <!-- begining of page level js -->
    <script  type="text/javascript" src="{{ asset('assets/vendors/bootstrapvalidator/js/bootstrapValidator.min.js') }}"></script>
    <script src="{{asset('assets/vendors/iCheck/js/icheck.js')}}" type="text/javascript"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/login1.js') }}"></script>
    <!-- end of page level js -->
</body>

</html>
