@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Blank Page
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
@stop

{{-- Page content --}}
@section('content')

    <section class="content-header">
        <div class="container-fluid">
        <h2>Blank</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li class="active">
                Blank
            </li>
        </ol>
        </div>
    </section>
    <section class="content">
    </section>


@stop

{{-- page level scripts --}}
@section('footer_scripts')
@stop
