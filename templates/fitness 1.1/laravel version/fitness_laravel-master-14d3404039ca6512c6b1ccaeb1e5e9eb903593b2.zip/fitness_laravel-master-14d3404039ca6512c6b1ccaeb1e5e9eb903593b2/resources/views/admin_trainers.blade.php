@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Trainers
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/bootstrapvalidator/css/bootstrapValidator.min.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/vendors/sweetalert2/css/sweetalert2.min.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/vendors/datatables/css/dataTables.bootstrap.css') }}" rel="stylesheet"/>
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Trainers</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="#">Course Schedule</a>
            </li>
            <li class="active">
                Trainers
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <!--main content-->
            <div class="row">
                <div class="col-lg-12">
                    <!-- Basic charts strats here-->
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-fw fa-file-text-o"></i> Add Trainer
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form action="#" class="form-horizontal" id="trainer">
                                        <div class="form-body">
                                            <div class="form-group">
                                                <label class="col-md-3 control-label" for="trainer1">
                                                    Trainer Name
                                                    <span class='require'>*</span>
                                                </label>
                                                <div class="col-md-6">
                                                    <div class="input-group">
                                                            <span class="input-group-addon">
                                                                <i class="fa fa-fw fa-file-text-o"></i>
                                                            </span>
                                                        <input type="text" name="title" id="trainer1"
                                                               class="form-control" placeholder="Enter Title" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-6">
                                                    <input type="submit" class="btn btn-primary" value="Add"> &nbsp;
                                                    <input type="button" class="btn btn-danger" value="Cancel">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-fw fa-file-text-o"></i> Trainers
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body table-responsive">
                            <table class="table table-bordered" id="fitness-table1">
                                <thead>
                                <tr>
                                    <th>Trainer Name</th>
                                    <th>Edit/Save</th>
                                    <th>Delete/Cancel</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Amanda Bale</td>
                                    <td>
                                        <a class=" edit btn btn-primary mar-bm" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger mar-bm" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Alex Krasnov</td>
                                    <td>
                                        <a class=" edit btn btn-primary mar-bm" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger mar-bm" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Alexande Bergunov</td>
                                    <td>
                                        <a class=" edit btn btn-primary mar-bm" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger mar-bm" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Rachel Adams</td>
                                    <td>
                                        <a class=" edit btn btn-primary mar-bm" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger mar-bm" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Rachel Adams</td>
                                    <td>
                                        <a class=" edit btn btn-primary mar-bm" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger mar-bm" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col-md-6 -->
            <!--row ends-->
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/bootstrapvalidator/js/bootstrapValidator.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/sweetalert2/js/sweetalert2.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/trainers.js') }}"></script>
    <!-- end of page level js -->
@stop
