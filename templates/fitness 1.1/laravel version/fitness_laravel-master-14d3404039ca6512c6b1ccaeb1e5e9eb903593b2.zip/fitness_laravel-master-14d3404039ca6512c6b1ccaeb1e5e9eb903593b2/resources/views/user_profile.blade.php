@extends('layouts/default')

{{-- Page title --}}
@section('title')
    User Profile
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css  -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/jasny_bootstrap/css/jasny-bootstrap.css') }}"
          rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/css/pages/user_profile.css') }}" rel="stylesheet"/>
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Profile</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li class="active">
                User Profile
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-title">User Profile</div>
                </div>
                <div class="panel-body">
                    <!--main content-->
                    <div class="row">
                        <div class="col-md-3 text-center">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-new thumbnail">
                                    <img src="{{asset('assets/img/authors/avatar1.jpg')}}" alt="profile image"
                                         class="img-responsive">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                <div>
                                        <span class="btn btn-primary btn-file">
                                    <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="...">
                                        </span>
                                    <a href="#" class="btn btn-primary fileinput-exists"
                                       data-dismiss="fileinput">Remove</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <table class="table table-bordered">
                                <tr>
                                    <td>Username:</td>
                                    <td>Nataliapery</td>
                                </tr>
                                <tr>
                                    <td>Gender:</td>
                                    <td>Female</td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td>Nataliapery@fitness.com</td>
                                </tr>
                                <tr>
                                    <td>Phone Number:</td>
                                    <td>999-999-9999</td>
                                </tr>
                                <tr>
                                    <td>Address:</td>
                                    <td>Sydney, Australia</td>
                                </tr>
                                <tr>
                                    <td>Height:</td>
                                    <td>5.5ft</td>
                                </tr>
                                <tr>
                                    <td>Weight:</td>
                                    <td>55kg</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!-- end of page level js -->
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/jasny_bootstrap/js/jasny-bootstrap.js') }}"></script>
    <!-- end of page level js -->
@stop
