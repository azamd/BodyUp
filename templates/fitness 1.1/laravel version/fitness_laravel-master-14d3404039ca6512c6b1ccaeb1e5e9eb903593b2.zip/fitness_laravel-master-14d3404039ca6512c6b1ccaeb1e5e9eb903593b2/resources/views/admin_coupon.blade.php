@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Coupon
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')

    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link rel="stylesheet" href="{{ asset('assets/vendors/jasny_bootstrap/css/jasny-bootstrap.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/vendors/summernote/summernote.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/vendors/datetimepicker/css/bootstrap-datetimepicker.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/vendors/datatables/css/dataTables.bootstrap.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/vendors/bootstrapvalidator/css/bootstrapValidator.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/vendors/sweetalert2/css/sweetalert2.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/css/pages/timings.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/css/pages/coupon.css') }}">
    <!--end of page level css-->
@stop


{{-- Page content --}}
@section('content')

    <section class="content-header">
        <!--section starts-->
        <h2>Coupons</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li class="active">
                Coupon
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <!--main content-->
            <div class="row">
                <div class="col-lg-12">
                    <!-- Basic charts strats here-->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-scissors "></i> Add Coupon
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form id="coupon_form" action="#" class="form-horizontal">
                                        <div class="form-body">
                                            <div class="form-group">
                                                <label class="col-md-3 control-label" for="cupon">
                                                    Coupon Name
                                                    <span class='require'>*</span>
                                                </label>
                                                <div class="col-md-7">
                                                    <div class="input-group">
                                                            <span class="input-group-addon">
                                                                <i class="fa fa-fw fa-file-text-o"></i>
                                                            </span>
                                                        <input type="text" name="title" id="cupon" class="form-control"
                                                               placeholder="Enter Title">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Image</label>
                                                <div class="col-md-7 text-center">
                                                    <div class="input-group">
                                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <div class="fileinput-new thumbnail"
                                                                 style="width: 200px; height: 150px;">
                                                                <img data-src="holder.js/200x150" src="#" alt="profile">
                                                            </div>
                                                            <div class="fileinput-preview fileinput-exists thumbnail"
                                                                 style="max-width: 200px; max-height: 150px;"></div>
                                                            <div class="select_align">
                                                                    <span class="btn btn-primary btn-file">
                                                                        <span class="fileinput-new">Select image</span>
                                                                    <span class="fileinput-exists">Change</span>
                                                                    <input type="file" name="...">
                                                                    </span>
                                                                <a href="#" class="btn btn-primary fileinput-exists"
                                                                   data-dismiss="fileinput">Remove</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label" for="start">
                                                    Start *
                                                </label>
                                                <div class="col-md-3">
                                                    <div class='input-group date datetimepicker6'>
                                                        <input type='text' class="form-control" id="start"
                                                               name="date_start"/>
                                                        <span class="input-group-addon">
                                                                <span class="glyphicon glyphicon-time"></span>
                                                            </span>
                                                    </div>
                                                </div>
                                                <label class="col-md-1 control-label" for="end">
                                                    End *
                                                </label>
                                                <div class="col-md-3">
                                                    <div class='input-group date datetimepicker7'>
                                                        <input type='text' class="form-control" id="end"
                                                               name="date_end"/>
                                                        <span class="input-group-addon">
                                                                <span class="glyphicon glyphicon-time"></span>
                                                            </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label">Description<span class='require'> *</span></label>
                                                <div class="col-md-7 ">
                                                    <div class="input-group">
                                                        <textarea name="content"
                                                                  class="summernote edi-css form-control"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-actions">
                                            <div class="form-group">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <input type="submit" class="btn btn-primary" value="Add">
                                                    <input type="button" class="btn btn-danger" value="Cancel">
                                                    <input type="reset" ID="add-news-reset-editable"
                                                           class="btn btn-default" value="Reset">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Basic charts strats here-->
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-fw fa-file-text-o"></i> Present Coupons
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body table-responsive">
                            <table class="table table-bordered" id="fitness-table">
                                <thead>
                                <tr>
                                    <th>Coupon Name</th>
                                    <th>Duration</th>
                                    <th>Desciption</th>
                                    <th>Code</th>
                                    <th>Edit/Save</th>
                                    <th>Delete/Cancel</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Yoga</td>
                                    <td>3 Months</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>SF345K</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Fitness</td>
                                    <td>1 Week</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>QD144B</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Body Building</td>
                                    <td>1 Month</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>RTV46L</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Aerobics</td>
                                    <td>3 Months</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>AVX753</td>
                                    <td>
                                        <a class=" edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Flexibility</td>
                                    <td>2 Months</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</td>
                                    <td>TN682J</td>
                                    <td>
                                        <a class="edit btn btn-primary" href="javascript:;">
                                            <i class="fa fa-fw fa-edit"></i> Edit
                                        </a>
                                    </td>
                                    <td>
                                        <a class="delete btn btn-danger" href="javascript:;">
                                            <i class="fa fa-trash-o"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/vendors/moment/js/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/summernote/summernote.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/jasny_bootstrap/js/jasny-bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/moment/js/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datetimepicker/js/bootstrap-datetimepicker.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/bootstrapvalidator/js/bootstrapValidator.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/sweetalert2/js/sweetalert2.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/coupon.js') }}"></script>
    <!-- end of page level js -->
@stop
