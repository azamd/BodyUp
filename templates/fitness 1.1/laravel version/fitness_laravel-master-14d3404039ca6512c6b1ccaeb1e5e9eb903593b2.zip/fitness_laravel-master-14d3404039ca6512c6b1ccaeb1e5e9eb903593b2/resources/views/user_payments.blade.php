@extends('layouts/default')

{{-- Page title --}}
@section('title')
    User Payment
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/fancybox/jquery.fancybox.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/vendors/datatables/css/dataTables.bootstrap.css') }}"
          rel="stylesheet"/>
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Payment</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li class="active">
                Payment
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <!--main content-->
            <div class="row">
                <div class="col-lg-12">
                    <table class="table">
                        <tbody>
                        <tr class="text-center">
                            <td>
                                <h5>Course: <span>Aerobics</span></h5>
                            </td>
                            <td>
                                <h5>Duration: <span>6 Months</span></h5>
                            </td>
                            <td>
                                <h5>Total Amount: <span>$250</span></h5>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <div class="panel-title">
                                Payment History
                            </div>
                        </div>
                        <div class="panel-body text-center">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">Amount Paid</th>
                                        <th class="text-center">Amount Due</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>4th Mar 2015</td>
                                        <td>$50</td>
                                        <td>$200</td>
                                    </tr>
                                    <tr>
                                        <td>8th May 2015</td>
                                        <td>$120</td>
                                        <td>$130</td>
                                    </tr>
                                    <tr>
                                        <td>11th Aug 2015</td>
                                        <td>$80</td>
                                        <td>$170</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table">
                        <tbody>
                        <tr class="text-center">
                            <td>
                                <h5>Course: <span>Yoga</span></h5>
                            </td>
                            <td>
                                <h5>Duration: <span>3 Months</span></h5>
                            </td>
                            <td>
                                <h5>Total Amount: <span>$110</span></h5>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="panel-title">
                                Present Course Payments
                            </div>
                        </div>
                        <div class="panel-body text-center">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">Amount Paid</th>
                                        <th class="text-center">Amount Due</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>1st Sept 2015</td>
                                        <td>$60</td>
                                        <td>$50</td>
                                    </tr>
                                    <tr>
                                        <td>8th Sept 2015</td>
                                        <td>$30</td>
                                        <td>$80</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <a href="user_amntpayment" class="btn btn-primary">Proceed to Pay</a>
                    </div>
                </div>
            </div>
            <!-- col-md-6 -->
            <!--row ends-->
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/fancybox/jquery.fancybox.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/user_course_schedule.js') }}"></script>
    <!-- end of page level js -->
@stop
