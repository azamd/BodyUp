@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Course Schedule
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/datatables/css/dataTables.bootstrap.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/vendors/sweetalert2/css/sweetalert2.min.css') }}" rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/css/pages/user_course_schedule.css') }}" rel="stylesheet"/>
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Course Schedule</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="#">Course Info</a>
            </li>
            <li class="active">
                Course Schedule
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <!--main content-->
            <div class="row">
                <div class="col-lg-12">
                    <!-- Basic charts strats here-->
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <i class="fa fa-fw fa-user"></i> Course Schedule
                            </h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body table-responsive">
                            <ul class="nav nav-tabs nav-custom" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#mon" aria-controls="mon" role="tab" data-toggle="tab">
                                        <strong>Monday</strong>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#tue" aria-controls="tue" role="tab" data-toggle="tab">
                                        <strong>Tuesday</strong>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#wed" aria-controls="wed" role="tab" data-toggle="tab">
                                        <strong>Wednesday</strong>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#thu" aria-controls="thu" role="tab" data-toggle="tab">
                                        <strong>Thursday</strong>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#fri" aria-controls="fri" role="tab" data-toggle="tab">
                                        <strong>Friday</strong>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#sat" aria-controls="sat" role="tab" data-toggle="tab">
                                        <strong>Saturday</strong>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#sun" aria-controls="sun" role="tab" data-toggle="tab">
                                        <strong>Sunday</strong>
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="mon">
                                    <table class="table table-bordered text-center" id="table1">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Yoga</td>
                                            <td>Jane Austin</td>
                                            <td>Room-A</td>
                                            <td>10:00</td>
                                            <td>11:00</td>
                                        </tr>
                                        <tr>
                                            <td>Body Building</td>
                                            <td>Alex Krasnov</td>
                                            <td>Room-B</td>
                                            <td>10:30</td>
                                            <td>11:30</td>
                                        </tr>
                                        <tr>
                                            <td>Fitness</td>
                                            <td>Alexande Bergunov</td>
                                            <td>Room-C</td>
                                            <td>11:00</td>
                                            <td>12:00</td>
                                        </tr>
                                        <tr>
                                            <td>Aerobics</td>
                                            <td>Amanda Bale</td>
                                            <td>Room-D</td>
                                            <td>12:00</td>
                                            <td>13:00</td>
                                        </tr>
                                        <tr>
                                            <td>Flexibility</td>
                                            <td>Rachel Adams</td>
                                            <td>Room-E</td>
                                            <td>13:30</td>
                                            <td>14:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="tue">
                                    <table class="table table-bordered text-center" id="table2">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Yoga</td>
                                            <td>Jane Austin</td>
                                            <td>Room-A</td>
                                            <td>10:00</td>
                                            <td>11:00</td>
                                        </tr>
                                        <tr>
                                            <td>Body Building</td>
                                            <td>Alex Krasnov</td>
                                            <td>Room-B</td>
                                            <td>10:30</td>
                                            <td>11:30</td>
                                        </tr>
                                        <tr>
                                            <td>Fitness</td>
                                            <td>Alexande Bergunov</td>
                                            <td>Room-C</td>
                                            <td>11:00</td>
                                            <td>12:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="wed">
                                    <table class="table table-bordered  text-center" id="table3">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Aerobics</td>
                                            <td>Amanda Bale</td>
                                            <td>Room-D</td>
                                            <td>12:00</td>
                                            <td>13:00</td>
                                        </tr>
                                        <tr>
                                            <td>Flexibility</td>
                                            <td>Rachel Adams</td>
                                            <td>Room-E</td>
                                            <td>13:30</td>
                                            <td>14:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="thu">
                                    <table class="table table-bordered text-center" id="table4">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th>To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Flexibility</td>
                                            <td>Rachel Adams</td>
                                            <td>Room-E</td>
                                            <td>13:30</td>
                                            <td>14:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="fri">
                                    <table class="table table-bordered text-center" id="table5">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Yoga</td>
                                            <td>Jane Austin</td>
                                            <td>Room-A</td>
                                            <td>10:00</td>
                                            <td>11:00</td>
                                        </tr>
                                        <tr>
                                            <td>Aerobics</td>
                                            <td>Amanda Bale</td>
                                            <td>Room-D</td>
                                            <td>12:00</td>
                                            <td>13:00</td>
                                        </tr>
                                        <tr>
                                            <td>Flexibility</td>
                                            <td>Rachel Adams</td>
                                            <td>Room-E</td>
                                            <td>13:30</td>
                                            <td>14:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="sat">
                                    <table class="table table-bordered text-center" id="table6">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Yoga</td>
                                            <td>Jane Austin</td>
                                            <td>Room-A</td>
                                            <td>10:00</td>
                                            <td>11:00</td>
                                        </tr>
                                        <tr>
                                            <td>Body Building</td>
                                            <td>Alex Krasnov</td>
                                            <td>Room-B</td>
                                            <td>10:30</td>
                                            <td>11:30</td>
                                        </tr>
                                        <tr>
                                            <td>Fitness</td>
                                            <td>Alexande Bergunov</td>
                                            <td>Room-C</td>
                                            <td>11:00</td>
                                            <td>12:00</td>
                                        </tr>
                                        <tr>
                                            <td>Aerobics</td>
                                            <td>Amanda Bale</td>
                                            <td>Room-D</td>
                                            <td>12:00</td>
                                            <td>13:00</td>
                                        </tr>
                                        <tr>
                                            <td>Flexibility</td>
                                            <td>Rachel Adams</td>
                                            <td>Room-E</td>
                                            <td>13:30</td>
                                            <td>14:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="sun">
                                    <table class="table table-bordered text-center" id="table7">
                                        <thead>
                                        <tr>
                                            <th class="text-center">Course</th>
                                            <th class="text-center">Trainer</th>
                                            <th class="text-center">Room</th>
                                            <th class="text-center">From</th>
                                            <th class="text-center">To</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Yoga</td>
                                            <td>Jane Austin</td>
                                            <td>Room-A</td>
                                            <td>10:00</td>
                                            <td>11:00</td>
                                        </tr>
                                        <tr>
                                            <td>Flexibility</td>
                                            <td>Rachel Adams</td>
                                            <td>Room-E</td>
                                            <td>13:30</td>
                                            <td>14:00</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h4 class="panel-title"><i class="fa fa-clock-o"></i> Timing Views</h4>
                            <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up showhide clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel"></i>
                                </span>
                        </div>
                        <div class="panel-body table-responsive">
                            <div class="table-scrollable">
                                <table class="table table-bordered timings-tab">
                                    <thead>
                                    <tr class="table-heading-background">
                                        <th>MONDAY</th>
                                        <th>TUESDAY</th>
                                        <th>WEDNESDAY</th>
                                        <th>THURSDAY</th>
                                        <th>FRIDAY</th>
                                        <th>SATURDAY</th>
                                        <th>SUNDAY</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td class="inline1">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                09:00 - 10:00
                                                <br> <b>Fitness</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline2">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                09:00 - 11:00
                                                <br> <b>Yoga</b>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline3">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                10:00 - 11:00
                                                <br>
                                                <b>Aerobics</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline4">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                10:30 - 11:00
                                                <br>
                                                <b>Body Building</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="inline5">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                01:00 - 02:00
                                                <br>
                                                <b>Fitness</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="inline6">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                12:00 - 12:30
                                                <br>
                                                <b>Flexibility</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline7">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                12:00 - 13:00
                                                <br>
                                                <b>Body Building</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td class="inline8">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                12:33 - 13:33
                                                <br>
                                                <b>Yoga</b>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="inline9">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                13:00 - 14:00
                                                <br>
                                                <b>Fitness</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td class="inline10">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                13:30 - 14:30
                                                <br>
                                                <b>Flexibility</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="inline11">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                14:00 - 14:30
                                                <br>
                                                <b>Yoga</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline12">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                14:00 - 15:30
                                                <br>
                                                <b>Fitness</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="inline13">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                15:00 - 16:00
                                                <br>
                                                <b>Fitness</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline14">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                16:00 - 16:30
                                                <br>
                                                <b>Aerobics</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td class="inline15">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                17:00 - 18:00
                                                <br>
                                                <b>Body Building</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td class="inline16">
                                            <a href="#" title="Lorem ipsum dolor sit amet">
                                                18:00 - 19:00
                                                <br>
                                                <b>Body Building</b>
                                            </a>
                                        </td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col-md-6 -->
            <!--row ends-->
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/vendors/sweetalert2/js/sweetalert2.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/user_course_schedule.js') }}"></script>
    <!-- end of page level js -->
@stop
