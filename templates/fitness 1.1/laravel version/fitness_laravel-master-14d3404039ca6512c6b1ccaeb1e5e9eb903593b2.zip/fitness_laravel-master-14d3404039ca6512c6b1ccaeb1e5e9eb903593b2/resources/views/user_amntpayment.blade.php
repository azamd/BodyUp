@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Payment
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!--page level css -->
    <link type="text/css" href="{{ asset('assets/css/pages/payment.css') }}" rel="stylesheet">
    <!--end of page level css-->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Payment</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li class="active">
                Payment
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="panel-title">
                        Payment Mode
                    </div>
                </div>
                <div class="panel-body text-center">
                    <div class="table-responsive">
                        <div class="card-wrapper"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3 col-lg-offset-3 col-xs-12">
                            <div class="form-container active">
                                <form>
                                    <div class="form-group">
                                        <input placeholder="Card Number" class="form-control" type="text" name="number">
                                    </div>
                                    <div class="form-group">
                                        <input placeholder="Full Name" maxlength="16" class="form-control nameuser"
                                               type="text" name="name">
                                    </div>
                                    <div class="form-group">
                                        <input placeholder="MM/YY" class="form-control" type="text" name="expiry">
                                    </div>
                                    <div class="form-group">
                                        <input placeholder="CVC" class="form-control" type="text" name="cvc">
                                    </div>
                                    <div class="form-group text-center">
                                        <a href="#" class="btn btn-primary">Submit</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/pages/jquery.card.js') }}"></script>
    <script type="text/javascript" src="{{ asset('assets/js/pages/user_payment.js') }}"></script>
    <!-- end of page level js -->
@stop
