@extends('layouts/default')

{{-- Page title --}}
@section('title')
    Courses
    @parent
@stop

{{-- page level styles --}}
@section('header_styles')
    <!-- global css -->
    <link type="text/css" href="{{ asset('assets/css/pages/panel.css') }}" rel="stylesheet"/>
    <!-- end of global css -->
    <!-- page level css -->
    <link type="text/css" href="{{ asset('assets/vendors/bootstrapvalidator/css/bootstrapValidator.min.css') }}"
          rel="stylesheet"/>
    <link type="text/css" href="{{ asset('assets/css/pages/user_courses.css') }}" rel="stylesheet">
    <!-- end of page level css -->
@stop

{{-- Page content --}}
@section('content')
    <section class="content-header">
        <!--section starts-->
        <h2>Courses</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index">
                    <i class="fa fa-fw fa-home"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="#">Course Info</a>
            </li>
            <li class="active">
                Courses
            </li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="container-fluid">
            <div class="row box-btm box-attached">
                <div class="col-xs-12 col-lg-3">
                    <div class="headings bg-primary">
                        <div class="price">
                            <sup>$</sup>35
                            <small>1 Month</small>
                        </div>
                        <div class="type">
                            BASIC PLAN
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>60 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Standard Gym Program</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-lg-3">
                    <div class="headings bg-info">
                        <div class="price">
                            <sup>$</sup>50
                            <small>1 Month</small>
                        </div>
                        <div class="type">
                            MEDIUM PLAN
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>120 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Acrobates, Special Yoga</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-lg-3">
                    <div class="headings bg-danger">
                        <div class="price">
                            <sup>$</sup>100
                            <small>1 Month</small>
                        </div>
                        <div class="type">
                            ADVANCE PLAN
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>180 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Personal Trainer</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-lg-3">
                    <div class="headings bg-warning">
                        <div class="price">
                            <sup>$</sup>150
                            <small>1 Month</small>
                        </div>
                        <div class="type">
                            EXTENDED PLAN
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>180 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Personal Training Program</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row box-btm box-attached">
                <div class="col-xs-12 col-lg-4">
                    <div class="headings bg-primary">
                        <div class="price">
                            <sup>$</sup>99
                            <small>3 Months</small>
                        </div>
                        <div class="type">
                            Bronze
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>120 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Standard Gym Program, Special Yoga</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-lg-4">
                    <div class="headings bg-info">
                        <div class="price">
                            <sup>$</sup>299
                            <small>6 Months</small>
                        </div>
                        <div class="type">
                            Silver
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>180 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Personalised Training Program</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-lg-4">
                    <div class="headings bg-warning">
                        <div class="price">
                            <sup>$</sup>799
                            <small>Annual</small>
                        </div>
                        <div class="type">
                            Gold
                        </div>
                        <ul>
                            <li><i class="fa fa-angle-double-right"></i>Full Gym Induction</li>
                            <li><i class="fa fa-angle-double-right"></i>300 Minutes Session</li>
                            <li><i class="fa fa-angle-double-right"></i>Personal Training Sessions</li>
                        </ul>
                        <div class="pricing-footer">
                            <a href="#" class="btn btn-success btn-lg">Subscribe</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content -->
    </section>
    <!-- content -->

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <!-- begining of page level js -->
    <script type="text/javascript" src="{{ asset('assets/js/holder.js') }}"></script>
    <!-- end of page level js -->
@stop
