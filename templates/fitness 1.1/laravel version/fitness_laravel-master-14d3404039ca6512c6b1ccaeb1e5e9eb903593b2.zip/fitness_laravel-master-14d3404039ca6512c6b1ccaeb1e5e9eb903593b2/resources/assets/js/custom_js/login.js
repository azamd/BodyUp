"use strict";
$(document).ready(function() {
       
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-blue, input[type="radio"].minimal-blue').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass: 'iradio_minimal-blue'
        });
      
    });
       