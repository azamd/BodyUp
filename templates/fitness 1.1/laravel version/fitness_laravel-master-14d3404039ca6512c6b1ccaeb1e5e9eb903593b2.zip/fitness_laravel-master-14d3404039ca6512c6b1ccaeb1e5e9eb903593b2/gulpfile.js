var gulp = require("gulp");
var bower = require("gulp-bower");
var elixir = require("laravel-elixir");
gulp.task('bower', function () {
    return bower();
});

/*
 |--------------------------------------------------------------------------
 | Elixir Asset Management
 |--------------------------------------------------------------------------
 */
elixir.config.publicPath = 'public/assets';
var vendors = 'resources/assets/vendors/';
var resourcesAssets = 'resources/assets/';
var srcCss = resourcesAssets + 'css/';
var srcJs = resourcesAssets + 'js/';

//destination path configuration
var dest = 'public/assets/';
var destFonts = dest + 'fonts/';
var destCss = dest + 'css/';
var destJs = dest + 'js/';
var destImg = dest + 'img/';
var destImages = dest + 'images/';
var destVendors= dest + 'vendors/';

/*
 |--------------------------------------------------------------------------
 | Elixir Asset Management
 |--------------------------------------------------------------------------
 |
 | Elixir provides a clean, fluent API for defining some basic Gulp tasks
 | for your Laravel application. By default, we are compiling the Less
 | file for our application, as well as publishing vendor resources.
 |
 */
var paths = {
    'animate': vendors + 'animate.css/',
    'bootstraptagsinput': vendors + 'bootstrap-tagsinput/dist/',
    'summernote': vendors + 'summernote/dist/',
    'select2': vendors + 'select2/dist/',
    'select2BootstrapTheme': vendors + 'select2-bootstrap-theme/dist/',
    'bootstrapValidator': vendors + 'bootstrapvalidator/dist/',
    'fancybox': vendors +'fancybox/',
    'fileUpload' : vendors + 'blueimp-file-upload/',
    'blueimpgallery' : vendors + 'blueimp-gallery-with-desc/',
    'blueimptmpl' : vendors + 'blueimp-tmpl/',
    'imgLoad' : vendors + 'blueimp-load-image/',
    'blueimpcanvas' : vendors + 'blueimp-canvas-to-blob/',
    'datatables' : vendors + 'datatables/media/',
    'icheck': vendors + 'iCheck/',
    'bootstrap': vendors + 'bootstrap/dist/',
    'jasnyBootstrap': vendors + 'jasny-bootstrap/',
    'datetimepicker': vendors + 'eonasdan-bootstrap-datetimepicker/build/',
    'fontawesome': vendors + 'font-awesome/',
    'flotchart': vendors + 'flotchart/',
    'flottooltip' : vendors + 'flot.tooltip/js/',
    "flot.tooltip": "~0.8.5",
    'xeditable': vendors + 'x-editable/dist/',
    'moment': vendors + 'moment/',
    'verticaltimeline': vendors + 'vertical-timeline/',
    'airdatepicker': vendors + 'air-datepicker/dist/',
    'circliful': vendors + 'circliful/',
    'bootstrap_progressbar': vendors + 'bootstrap-progressbar/',
    'fullcalendar': vendors + 'fullcalendar/dist/',
    'bootstrap_select': vendors + 'bootstrap-select/dist/',
    'nvd3': vendors + 'nvd3/build/',
    'd3': vendors + 'd3/',
    'countUp': vendors + 'countUp.js/',
    "easyticker": vendors + 'jquery-easy-ticker-master/',
    "inputmask": vendors + 'jquery.inputmask/dist/',
    'owlcarousel': vendors + 'owl.carousel/owl-carousel/',
    'ihover': vendors + 'ihover/',
    'mixitup': vendors + 'mixitup/',
    'chartjs': vendors + 'Chart.js/',
    'liquidgauge': vendors + 'd3-liquid-fill-gauge/',
    'sweetalert2': vendors + 'sweetalert2/dist/'


};

elixir.config.sourcemaps = false;

elixir(function (mix) {

    // Run bower install
    mix.task('bower');

    //delete all files first
    //mix.task('delete');

    //copy frontend skins to public
    mix.copy(srcCss + 'frontend/skins', destCss + 'frontend/skins');


    // Copy fonts straight to public
    mix.copy(paths.bootstrap + 'fonts', destFonts);
    mix.copy(paths.fontawesome + 'fonts', destFonts);


    // Copy images straight to public
    mix.copy(paths.jqueryui + 'themes/base/images', destImg);
    mix.copy(resourcesAssets + 'img', destImg);
    mix.copy(resourcesAssets + 'images', destImages);

    // Newly added plugins

    // bootstraptagsinput
     mix.copy(paths.bootstraptagsinput + 'bootstrap-tagsinput.css', destVendors + 'bootstrap_tagsinput/css');
     mix.copy(paths.bootstraptagsinput + 'bootstrap-tagsinput.js', destVendors + 'bootstrap_tagsinput/js');

    // summer note
    mix.copy(paths.summernote + 'summernote.css', destVendors + 'summernote');
    mix.copy(paths.summernote + 'summernote.min.js', destVendors + 'summernote');

    //select2
    mix.copy(paths.select2 + 'css/select2.min.css', destVendors + 'select2/css');
    mix.copy(paths.select2 + 'js/select2.min.js', destVendors + 'select2/js');
    mix.copy(paths.select2BootstrapTheme + 'select2-bootstrap.min.css', destVendors + 'select2/css');

    // bootstrapvalidator
    mix.copy(paths.bootstrapValidator + 'css/bootstrapValidator.min.css', destVendors + 'bootstrapvalidator/css');
    mix.copy(paths.bootstrapValidator + 'js/bootstrapValidator.min.js', destVendors + 'bootstrapvalidator/js');

    // Sweet Alert
    mix.copy(paths.sweetalert2 + 'sweetalert2.min.css', destVendors + 'sweetalert2/css');
    mix.copy(paths.sweetalert2 + 'sweetalert2.min.js', destVendors + 'sweetalert2/js');

    //fancybox
    mix.copy(paths.fancybox + 'source',  destVendors + 'fancybox');
    mix.copy(paths.fancybox + 'lib/jquery.mousewheel-3.0.6.pack.js',  destVendors + 'fancybox');

    // jquery file upload
    mix.copy(paths.fileUpload + 'css/jquery.fileupload.css',  destVendors + 'blueimp-file-upload/css');
    mix.copy(paths.fileUpload + 'css/jquery.fileupload-ui.css',  destVendors + 'blueimp-file-upload/css');
    mix.copy(paths.fileUpload + 'css/jquery.fileupload-noscript.css',  destVendors + 'blueimp-file-upload/css');
    mix.copy(paths.fileUpload + '/css/jquery.fileupload-ui-noscript.css',  destVendors + 'blueimp-file-upload/css');
    mix.copy(paths.fileUpload + 'js/vendor/jquery.ui.widget.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.iframe-transport.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload-process.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload-image.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload-audio.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload-video.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload-validate.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'js/jquery.fileupload-ui.js',  destVendors + 'blueimp-file-upload/js');
    mix.copy(paths.fileUpload + 'img/loading.gif',  destVendors + 'blueimp-file-upload/img');
    mix.copy(paths.fileUpload + 'img/loading.gif', dest + 'img');

    // blueimp-tmpl
    mix.copy(paths.blueimptmpl + 'js/tmpl.min.js',  destVendors + 'blueimp-tmpl/js');

    // blueimp-load-image
    mix.copy(paths.imgLoad + 'js/load-image.all.min.js',  destVendors + 'blueimploadimage/js');
    mix.copy(paths.imgLoad + 'js/load-image.js',  destVendors + 'blueimploadimage/js');

    // blueimp-canvas-to-blob
    mix.copy(paths.blueimpcanvas + 'js/canvas-to-blob.min.js',  destVendors + 'blueimp-canvas-to-blob/js');

    // blueimp-gallery-with-desc
    mix.copy(paths.blueimpgallery + 'css/blueimp-gallery.min.css',  destVendors + 'blueimp-gallery-with-desc/css');
    mix.copy(paths.blueimpgallery + 'js/jquery.blueimp-gallery.min.js',  destVendors + 'blueimp-gallery-with-desc/js');

    //icheck
    mix.copy(paths.icheck + 'icheck.js', destVendors + 'iCheck/js');
    mix.copy(paths.icheck + 'skins/', destVendors + 'iCheck/css');

    //jasny-bootstrap
    mix.copy(paths.jasnyBootstrap + 'dist/css/jasny-bootstrap.css', destVendors + 'jasny_bootstrap/css');
    mix.copy(paths.jasnyBootstrap + 'dist/js/jasny-bootstrap.js', destVendors + 'jasny_bootstrap/js');
    mix.copy(paths.jasnyBootstrap + 'js/inputmask.js', destVendors + 'jasny_bootstrap/js');


    // bootstrap-datetimepicker
    mix.copy(paths.datetimepicker + 'css/bootstrap-datetimepicker.min.css', destVendors + 'datetimepicker/css');
    mix.copy(paths.datetimepicker + 'js/bootstrap-datetimepicker.min.js', destVendors + 'datetimepicker/js');

    // x-editable
    mix.copy(paths.xeditable + 'bootstrap3-editable/css/bootstrap-editable.css', destVendors + 'x-editable/css');
    mix.copy(paths.xeditable + 'bootstrap3-editable/js/bootstrap-editable.js', destVendors + 'x-editable/js');
    mix.copy(paths.xeditable + 'bootstrap3-editable/img', destVendors + 'x-editable/img');
    mix.copy(paths.xeditable + 'inputs-ext/typeaheadjs/lib/typeahead.js', destVendors + 'x-editable/js');
    mix.copy(paths.xeditable + 'inputs-ext/typeaheadjs/lib/typeahead.js-bootstrap.css', destVendors + 'x-editable/css');
    mix.copy(paths.xeditable + 'inputs-ext/typeaheadjs/typeaheadjs.js', destVendors + 'x-editable/js');
    mix.copy(paths.xeditable + 'inputs-ext/address/address.js', destVendors + 'x-editable/js');

    // moment
    mix.copy(paths.moment + 'min/moment.min.js', destVendors + 'moment/js');

    // datatables
    mix.copy(paths.datatables + 'js/jquery.dataTables.js',  destVendors + 'datatables/js');
    mix.copy(paths.datatables + 'js/dataTables.bootstrap.js',  destVendors + 'datatables/js');
    mix.copy(paths.datatables + 'css/dataTables.bootstrap.css',  destVendors + 'datatables/css');
    mix.copy(paths.datatables + 'images/',  destVendors + 'datatables/images');


    // flot charts
    mix.copy(paths.flotchart + 'jquery.flot.js', destVendors + 'flotchart/js');
    mix.copy(paths.flotchart + 'jquery.flot.resize.js', destVendors + 'flotchart/js');
    mix.copy(paths.flotchart + 'jquery.flot.categories.js', destVendors + 'flotchart/js');
    mix.copy(paths.flottooltip + 'jquery.flot.tooltip.js',  destVendors + 'flotchart/js');

    // vertical timeline
    mix.copy(paths.verticaltimeline + 'css/reset.css', destVendors + 'verticaltimeline/css');
    mix.copy(paths.verticaltimeline + 'css/style.css', destVendors + 'verticaltimeline/css');
    mix.copy(paths.verticaltimeline + 'js/main.js',  destVendors + 'verticaltimeline/js');
    mix.copy(paths.verticaltimeline + 'js/modernizr.js',  destVendors + 'verticaltimeline/js');
    mix.copy(paths.verticaltimeline + 'img',  destVendors + 'verticaltimeline/img');

    //airdatepicker
    mix.copy(paths.airdatepicker + 'css/datepicker.min.css', destVendors + 'air-datepicker/css');
    mix.copy(paths.airdatepicker + 'js/datepicker.min.js', destVendors + 'air-datepicker/js');
    mix.copy(paths.airdatepicker + 'js/i18n/datepicker.en.js', destVendors + 'air-datepicker/js');

    //circliful
    mix.copy(paths.circliful + 'css/jquery.circliful.css', destVendors + 'circliful/css');
    mix.copy(paths.circliful + 'js/jquery.circliful.min.js', destVendors + 'circliful/js');

    // bootstrap progressbar
    mix.copy(paths.bootstrap_progressbar + 'css/bootstrap-progressbar-3.3.4.min.css', destVendors + 'bootstrap-progressbar/css');
    mix.copy(paths.bootstrap_progressbar + 'bootstrap-progressbar.min.js', destVendors + 'bootstrap-progressbar/js');

    // fullcalendar
    mix.copy(paths.fullcalendar + 'fullcalendar.css', destVendors + 'fullcalendar/css');
    mix.copy(paths.fullcalendar + 'fullcalendar.print.css', destVendors + 'fullcalendar/css');
    mix.copy(paths.fullcalendar + 'fullcalendar.min.js', destVendors + 'fullcalendar/js');

    //bootstrap-select
    mix.copy(paths.bootstrap_select + 'css/bootstrap-select.min.css', destVendors + 'bootstrap-select/css');
    mix.copy(paths.bootstrap_select + 'js/bootstrap-select.min.js', destVendors + 'bootstrap-select/js');

    //nvd3
    mix.copy(paths.nvd3 + 'nv.d3.min.js', destVendors + 'nvd3/js');
    mix.copy(paths.nvd3 + 'nv.d3.min.css', destVendors + 'nvd3/css');

    // countUp js
    mix.copy(paths.countUp + 'countUp.min.js', destVendors + 'countup/js');

    //d3
    mix.copy(paths.d3 + 'd3.min.js', destVendors + 'd3');

    // easyticker
    mix.copy(paths.easyticker + 'jquery.easy-ticker.min.js', destVendors + 'easyticker/js');

    // inputmask
    mix.copy(paths.inputmask + 'inputmask', destVendors + 'inputmask/js');

    // owl-carousel
    mix.copy(paths.owlcarousel + 'owl.carousel.css', destVendors + 'owl_carousel/css');
    mix.copy(paths.owlcarousel + 'owl.theme.css', destVendors + 'owl_carousel/css');
    mix.copy(paths.owlcarousel + 'owl.transitions.css', destVendors + 'owl_carousel/css');
    mix.copy(paths.owlcarousel + 'owl.carousel.min.js', destVendors + 'owl_carousel/js');

    //ihover
    mix.copy(paths.ihover + 'dist/scripts/app.js', destVendors + 'ihover/js');
    mix.copy(paths.ihover + 'src/ihover.css', destVendors + 'ihover/css');

    //mixitup
    mix.copy(paths.mixitup + 'build/jquery.mixitup.min.js', destVendors + 'mixitup/js');

    // d3 liquid fill gauge
    mix.copy(paths.liquidgauge + 'liquidFillGauge.js', destVendors + 'liquid_gauge/js');

    // Chart.js
    mix.copy(paths.chartjs + 'Chart.min.js', destVendors + 'chartjs');

    // bootstrap & jquery into custom css and js pages
    mix.copy( srcCss + 'bootstrap.min.css', destCss);
    mix.copy( srcJs + 'bootstrap.min.js', destJs);
    mix.copy( srcJs + 'jquery.min.js', destJs);



     // all pages custom css & js
    // faq
    mix.copy(srcCss + 'custom_css/add_faq.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/add_faq.js',  destJs + 'pages');

    // add users custom css & js
    mix.copy(srcCss + 'custom_css/add_users.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/add_users.js',  destJs + 'pages');

    // admin add news custom css & js
    mix.copy(srcCss + 'custom_css/add_news.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/add_news.js',  destJs + 'pages');

    // panel css
    mix.copy(srcCss + 'custom_css/panel.css',  destCss + 'pages');

    // admin add news custom css & js
    mix.copy(srcCss + 'custom_css/club_info.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/club_info.js',  destJs + 'pages');

    // admin coupon custom css & js
    mix.copy(srcCss + 'custom_css/timings.css',  destCss + 'pages');
    mix.copy(srcCss + 'custom_css/coupon.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/coupon.js',  destJs + 'pages');

    // admin course schedule
    mix.copy(srcCss + 'custom_css/course_schedule.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/course_schedule.js',  destJs + 'pages');

    // admin rooms
    mix.copy(srcJs + 'custom_js/rooms.js',  destJs + 'pages');

    // holder js
    mix.copy(srcJs + 'holder.js',  destJs );

    // admin course schedule
    mix.copy(srcJs + 'custom_js/timings.js',  destJs + 'pages');

    // admin trianers
    mix.copy(srcJs + 'custom_js/trainers.js',  destJs + 'pages');

    // admin users list
    mix.copy(srcCss + 'custom_css/users_list.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/users_list.js',  destJs + 'pages');

    // admin user news
    mix.copy(srcCss + 'custom_css/user_news.css',  destCss + 'pages');

    // admin user payments
    mix.copy(srcCss + 'custom_css/payment.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/payment.js',  destJs + 'pages');

    // admin user profile
    mix.copy(srcCss + 'custom_css/single_user.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/single_user.js',  destJs + 'pages');
    mix.copy(srcJs + 'jquery.mockjax.js',  destJs);

    // courses
    mix.copy(srcJs + 'custom_js/courses.js',  destJs + 'pages');

    // event item
    mix.copy(srcCss + 'custom_css/events.css',  destCss + 'pages');

    // events list
    mix.copy(srcCss + 'custom_css/events.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/events.js',  destJs + 'pages');

    // faq
    mix.copy(srcCss + 'custom_css/faq.css',  destCss + 'pages');

    // gallery
    mix.copy(srcCss + 'custom_css/portfolio.css',  destCss + 'pages');
    mix.copy(srcCss + 'custom_css/figcaption.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/portfolio.js',  destJs + 'pages');

    // index
    mix.copy(srcCss + 'custom_css/calendar_custom.css',  destCss + 'pages');
    mix.copy(srcCss + 'custom_css/admin_dashboard.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/admin_index.js',  destJs + 'pages');
    mix.copy(srcJs + 'custom_js/backstretch.js',  destJs + 'pages');

    // news
    mix.copy(srcCss + 'custom_css/news.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/news.js',  destJs + 'pages');

    // news details
    mix.copy(srcJs + 'custom_js/news_details.js',  destJs + 'pages');

    // packages
    mix.copy(srcJs + 'custom_js/packages.js',  destJs + 'pages');

    // carousel copy
    mix.copy(srcJs + 'carousel.js',  destJs );

    // personal training
    mix.copy(srcCss + 'custom_css/personaltraining.css',  destCss + 'pages');
    mix.copy(srcCss + 'custom_css/instructors.css',  destCss + 'pages');

    // user payment
    mix.copy(srcCss + 'custom_css/payment.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/jquery.card.js',  destJs + 'pages');
    mix.copy(srcJs + 'custom_js/user_payment.js',  destJs + 'pages');

    // user_course_schedule
    mix.copy(srcCss + 'custom_css/user_course_schedule.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/user_course_schedule.js',  destJs + 'pages');

    // user courses
    mix.copy(srcCss + 'custom_css/user_courses.css',  destCss + 'pages');

    // user_events
    mix.copy(srcCss + 'custom_css/events.css',  destCss + 'pages');

    // faq
    mix.copy(srcCss + 'custom_css/faq.css',  destCss + 'pages');

    // user index
    mix.copy(srcCss + 'custom_css/index.css',  destCss + 'pages');
    mix.copy(srcCss + 'custom_css/user_dashboard.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/dashboard.js',  destJs + 'pages');

    // user profile
    mix.copy(srcCss + 'custom_css/user_profile.css',  destCss + 'pages');

    // login page css & js
    mix.copy(srcCss + 'custom_css/login.css',  destCss + 'pages');
    mix.copy(srcJs + 'custom_js/login1.js',  destJs + 'pages');

    // admin login css & js
    mix.copy(srcCss + 'custom_css/admin-login.css',  destCss + 'pages');

    // add gallery
    mix.copy(srcJs + 'custom_js/add_gallery.js',  destJs + 'pages');

    // 404 page css
    mix.copy(srcCss + 'custom_css/404.css',  destCss + 'pages');


    // Custom Styles
    //black color scheme
    mix.styles(
        [
            'fonts.css', 'bootstrap.min.css', 'font-awesome.min.css','custom_css/fitness.css', 'custom_css/metisMenu.css'
        ], destCss + 'app.css');

    // all global js files into app.js
    mix.scripts(
        [
            'jquery.min.js',
            'bootstrap.min.js',
            'holder.js',
            'custom_js/metisMenu.js',
            '../js/custom_js/app.js'
        ], destJs + 'app.js');


});
