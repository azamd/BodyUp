<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;

class FitnessController extends Controller
{

    public function showView($name)
    {
        if(View::exists($name))
        {
            return view($name);
        }
        else
        {
            return view('404');
        }
    }
}
